<?php

const SampleCart = array(
    "item_amt" => 65,
    "tax_amt" => 0,
    "insurance_fee" => 0,
    "handling_fee" => 0,
    "shipping_amt" => 0,
    "shipping_discount" => 0,
    "total_amt" => 65,
    "currency" => "USD",
    "shipping_info" => array(
        "recipient_name" => "Taro Test",
        "line1" => "5 Temasek Boulevard",
        "line2" => "09-01 Suntec Tower Five",
        "city" => "Singapore",
        "state" => "Singapore",
        "postal_code" => "038985"
    )
);
